<nav class="bg-[#6bb135] py-3 px-4 flex space-x-6 justify-end text-white sticky top-0 z-50">
    <a>Pharmacy</a>
    <a>Find a Psychiatrist</a>
    <a>Our Story</a>
    <a>Contact Us</a>
    <a href="logout.php" class="cursor-pointer">
        <span class="material-icons">
            logout
        </span>
    </a>
</nav>