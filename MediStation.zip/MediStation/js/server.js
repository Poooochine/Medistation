const { createServer } = require("http");
const { Server } = require("socket.io");
const express = require("express");
const roomManager = require("./roomManager");
const path = require("path");
const fs = require("fs");

const app = express();

const server = createServer(app);

// const server = createServer(
//   {
//     key: fs.readFileSync(path.join(__dirname, "cert", "key.pem")),
//     cert: fs.readFileSync(path.join(__dirname, "cert", "cert.pem")),
//   },
//   app
// );


// Initialize server
const io = new Server(server, {
  maxHttpBufferSize: 1e20,
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});


// List of rooms
var rooms = [];

// accept connections and handel different events
io.on("connection", (socket) => {
  // Join a room if it exists
  socket.on("join room", ({ roomID, user }) => {
    roomManager.get_room(roomID).then((data) => {
      if (data) {
        const room = rooms.find((r) => r.id === data.id);
        socket.join(roomID);
        const userData = {
          userId: socket.id,
          accountId: user.accountId,
          name: user.name,
        };
        if (room) {
          if (room.users.length === 6) {
            socket.emit("room full");
            return;
          }
          room.users.push(userData);
          const users = room.users.filter((u) => u.userId !== socket.id);
          socket.emit("all users", users);
        } else {
          const roomData = {
            id: data.id,
            users: [userData],
          }
          rooms.push(roomData);
        }
      } else {
        const room = rooms.find((r) => r.id === roomID);
        if (room) {
          rooms = rooms.filter((room) => room.id !== roomID)
        }
        socket.emit("room not found");
        return;
      }
    })
  });

  // Add user to a call
  socket.on("sending signal", (payload) => {
    io.to(payload.userToSignal).emit("user joined", {
      signal: payload.signal,
      callerID: payload.callerID,
      name: payload.name,
      accountId: payload.accountId,
    });
  });

  socket.on("returning signal", (payload) => {
    io.to(payload.callerID).emit("receiving returned signal", {
      signal: payload.signal,
      id: socket.id,
    });
  });

  // send message to everyone in a room.
  socket.on("message", (data) => {
    io.to(data.roomID).emit("message", data);
  });

  // handel user disconnect event.
  socket.on("disconnect", () => {
    rooms.every((room) => {
      const user = room.users.find((u) => u.userId === socket.id);
      if (user) {
        io.to(room.id).emit("left", socket.id);
        room.users = room.users.filter((u) => u.userId !== socket.id);
        return false;
      }
    });
  });
});

// Start server
server.listen(5000, "0.0.0.0", () =>
  console.log(`Server has started on 0.0.0.0 using port 5000`)
);
