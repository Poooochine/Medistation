const { io } = require("socket.io-client");
const Peer = require("simple-peer");

const socket = io.connect("localhost:5000");

const main = document.getElementById("main");
const reconnect = document.getElementById("reconnect");

var peers = [];
var myStream;
var muted = false;
var video = true;
var recording = false;
var record;
var recordingStream;
var screenStr;

const username = document.getElementById("username").value;
const myId = document.getElementById("accountId").value;

// Get meeting room
const params = new URLSearchParams(window.location.search);
const roomID = params.get("room");

Array.prototype.listeners = {};
Array.prototype.addListener = function (eventName, callback) {
  if (!this.listeners[eventName]) {
    // Create a new array for new events
    // idea of an array is we can invoke all callbacks
    this.listeners[eventName] = [];
  }
  this.listeners[eventName].push(callback);
};
// New push Method
// Calls trigger event
Array.prototype.pushWithEvent = function () {
  const size = this.length;
  const argsList = Array.prototype.slice.call(arguments);
  for (let index = 0; index < argsList.length; index++) {
    this[size + index] = argsList[index];
  }
  // trigger add event
  this.triggerEvent("add", argsList);
};
Array.prototype.newFilter = function (callback, context) {
  const result = [];
  for (let index = 0; index < this.length; index++) {
    if (callback.call(context, this[index], index, this)) {
      result.push(this[index]);
    }
  }
  this.triggerEvent("remove", result);
  return result;
};
Array.prototype.triggerEvent = function (eventName, elements) {
  if (this.listeners[eventName] && this.listeners[eventName].length) {
    this.listeners[eventName].forEach((callback) =>
      callback(eventName, elements, this)
    );
  }
};


// Get access to the user camera and audio feed.
navigator.mediaDevices
  .getUserMedia({ video: true, audio: true })
  .then((stream) => {
    myStream = stream;
    setTimeout(() => {
      createVideoObject(myStream, true, socket.id);
      // Join call
      socket.emit("join room", {
        roomID,
        user: { accountId: myId, name: username },
      });
      // Rejoin call if user got disconnected
      socket.on("connect", () => {
        socket.emit("join room", {
          roomID,
          user: { accountId: myId, name: username },
        });
        reconnect.classList.remove("flex");
        reconnect.classList.add("hidden");
      });
      socket.on("connect_error", () => {
        reconnect.classList.remove("hidden");
        reconnect.classList.add("flex");
        document.getElementById("connect-text").textContent = "Connecting";
      });
      socket.on("disconnect", () => {
        peers.forEach((peer) => {
          removePeer(peer.peerID);
        });
        peers = [];
        document.getElementById("connect-text").textContent = "Reconnecting";
        reconnect.classList.remove("hidden");
        reconnect.classList.add("flex");
      });
      // Get users on call
      socket.on("all users", (users) => {
        users.forEach(({ userId, accountId, name }) => {
          const peer = createPeer(userId, socket.id, myStream, username, myId);
          peers.pushWithEvent({
            peerID: userId,
            accountId,
            name,
            peer,
          });
        });
      });
      //   Add new user to call
      socket.on("user joined", (payload) => {
        const peer = addPeer(payload.signal, payload.callerID, myStream);
        peers.pushWithEvent({
          peerID: payload.callerID,
          accountId: payload.accountId,
          name: payload.name,
          peer,
        });
      });
      socket.on("receiving returned signal", (payload) => {
        const item = peers.find((p) => p.peerID === payload.id);
        item.peer.signal(payload.signal);
      });
      socket.on("left", (id) => {
        removePeer(id);
      });
      //   listen for new messages
      socket.on("message", (data) => {
        addMessage(data);
      });
      socket.on("room full", () => {
        alert("Room full!");
        window.location = "login.php";
      });
      socket.on("room not found", () => {
        alert("Room not found!");
        window.location = "login.php";
      });
    }, 1500)
  })
  .catch((err) => {
    alert(err);
    window.location = "login.php";
  });

//   Add users video to the dom (Web-page)
const createVideoObject = (stream, muted, id) => {
  var videoTag = document.createElement("video");
  videoTag.srcObject = stream;
  videoTag.muted = muted;
  videoTag.id = id;
  videoTag.classList.add("rounded");
  videoTag.width = 440;
  videoTag.height = 440;
  videoTag.autoplay = true;
  main.appendChild(videoTag);
};


// Create a connection between users
const createPeer = (userToSignal, callerID, stream, username, accountId) => {
  const peer = new Peer({
    initiator: true,
    trickle: false,
    stream,
  });
  peer.on("signal", (signal) => {
    socket.emit("sending signal", {
      userToSignal,
      callerID,
      signal,
      name: username,
      accountId,
    });
  });
  peer.on("error", (err) => {
    removePeer(callerID);
    console.log(callerID);
    console.log(err);
  });

  return peer;
};

// Add a new user connection
const addPeer = (incomingSignal, callerID, stream) => {
  const peer = new Peer({
    initiator: false,
    trickle: false,
    stream,
  });
  peer.on("signal", (signal) => {
    socket.emit("returning signal", { signal, callerID });
  });
  peer.on("error", (err) => {
    window.location.reload();
  });
  peer.signal(incomingSignal);

  return peer;
};

// remover user when disconnect
const removePeer = (id) => {
  const user = peers.find((p) => p.peerID === id);
  if (user) {
    user.peer.destroy();
    peers = peers.filter((p) => p.peerID !== id);
    peers.newFilter((p) => p.peerID !== id);
    const userVideo = document.getElementById(id);
    userVideo.remove();
  }
};

// listen for new users and add them to the call
peers.addListener("add", (items, args) => {
  args.map((user) => {
    user.peer.on("stream", (stream) => {
      createVideoObject(stream, false, user.peerID);
    });
  });
});

// mute user
const muteMe = () => {
  muted = !muted;
  myStream.getAudioTracks()[0].enabled = !muted;
  createMuteButton();
};

// Toggle camera
const videoToggle = () => {
  video = !video;
  myStream.getVideoTracks()[0].enabled = video;
  createVideoButton();
};

// Add mute button to the dom
const createMuteButton = () => {
  const muteContainer = document.getElementById("muted");
  const oldButton = document.getElementById("old-button");
  var muteButton = document.createElement("button");
  muteButton.id = "old-button";
  var muteIcon = document.createElement("span");
  muteIcon.className = "material-icons";
  var text = document.createTextNode("keyboard_voice");
  muteIcon.appendChild(text);
  if (muted) {
    muteButton.className =
      "p-2 rounded bg-red-500 text-white flex items-center justify-center";
  } else {
    muteButton.className =
      "p-2 rounded bg-gray-700 text-white flex items-center justify-center";
  }
  muteButton.appendChild(muteIcon);
  muteContainer.replaceChild(muteButton, oldButton);
  muteButton.onclick = muteMe;
};

// Add video button to the dom
const createVideoButton = () => {
  const muteContainer = document.getElementById("video");
  const oldButton = document.getElementById("old-video");
  var videoButton = document.createElement("button");
  videoButton.id = "old-video";
  var videoIcon = document.createElement("span");
  videoIcon.className = "material-icons";
  var text = document.createTextNode("videocam");
  videoIcon.appendChild(text);
  if (video) {
    videoButton.className =
      "p-2 rounded bg-gray-700 text-white flex items-center justify-center";
  } else {
    videoButton.className =
      "p-2 rounded bg-red-500 text-white flex items-center justify-center";
  }
  videoButton.appendChild(videoIcon);
  muteContainer.replaceChild(videoButton, oldButton);
  videoButton.onclick = videoToggle;
};

createMuteButton();
createVideoButton();

// End call
const endCall = () => {
  window.location = "login.php";
};

const toggleChat = () => {
  const chatContainer = document.getElementById("chat");
  if (chatContainer.classList.contains("hidden")) {
    chatContainer.classList.remove("hidden");
    setTimeout(() => {
      chatContainer.classList.add("show");
    }, 100);
  }
  if (chatContainer.classList.contains("show")) {
    chatContainer.classList.remove("show");
    setTimeout(() => {
      chatContainer.classList.add("hidden");
    }, 500);
  }
  // chatContainer.classList.toggle("hidden");
  // chatContainer.classList.toggle("show");
};

const endButton = document.getElementById("end-call");
endButton.onclick = endCall;

const chatButton = document.getElementById("chat-button");
chatButton.onclick = toggleChat;

const messageInput = document.getElementById("message-input");

messageInput.addEventListener("keyup", (event) => {
  const sendButton = document.getElementById("send-button");
  if (messageInput.value) {
    sendButton.classList.add("flex");
    sendButton.classList.remove("hidden");
  } else {
    sendButton.classList.remove("flex");
    sendButton.classList.add("hidden");
  }
  if (event.code === "Enter") {
    sendMessage();
    sendButton.classList.remove("flex");
    sendButton.classList.add("hidden");
  }
});

// Send message to room
const sendMessage = () => {
  const data = {
    roomID,
    sender: { id: socket.id, name: username },
    message: messageInput.value,
  };
  if (messageInput.value) {
    socket.emit("message", data);
    messageInput.value = null;
  }
};

// scroll to bottom of messages
function scrollToBottom() {
  const s = document.getElementById("message-container");
  s.scrollTo({
    top: s.scrollHeight - s.clientHeight,
    behavior: "smooth",
  });
}

const sendButton = document.getElementById("send-button");
sendButton.onclick = sendMessage;

// Add message to the dom
const addMessage = (data) => {
  const messageContainer = document.getElementById("message-container");
  const messageDiv = document.createElement("div");
  const textDiv = document.createElement("div");
  const message = document.createElement("p");
  const messageSpan = document.createElement("span");
  const text = document.createTextNode(data.message);
  const spanText = document.createTextNode(data.sender.name);
  message.appendChild(text);
  messageSpan.appendChild(spanText);
  messageSpan.className =
    "text-xs text-right text-gray-200 justify-end text-ellipsis overflow-hidden";
  textDiv.appendChild(message);
  textDiv.appendChild(messageSpan);

  if (data.sender.id === socket.id) {
    textDiv.className =
      "flex flex-col bg-blue-500 text-white px-4 py-1 rounded-lg min-w-[40%] max-w-[85%]";
    messageDiv.className = "flex mx-2 justify-end";
  } else {
    textDiv.className =
      "flex flex-col bg-slate-700 text-white px-4 py-1 rounded-lg min-w-[40%] max-w-[85%]";
    messageDiv.className = "flex mx-2";
  }
  messageDiv.appendChild(textDiv);
  messageContainer.appendChild(messageDiv);
  scrollToBottom();
};

// Convert recording to mp4
const convertToMp4 = (blob) => {
  const vid = new Blob(blob, { type: "video/x-matroska;codecs=avc1,opus" });
  var a = document.createElement("a");
  document.body.appendChild(a);
  a.style = "display: none";
  var url = window.URL.createObjectURL(vid);
  a.href = url;
  a.download = Date.now();
  a.click();
  window.URL.revokeObjectURL(url);
};

// end recording
const endRecording = () => {
  record.stop();
  recording = false;
  recordButton.classList.add("bg-gray-700");
  recordButton.classList.remove("bg-red-500");
  const tracks = recordingStream.getTracks();
  tracks.forEach((track) => {
    track.stop();
  });
  screenStr.getTracks().forEach((track) => {
    track.stop();
  });
};

// Start recording
const toggleRecording = async () => {
  const recordButton = document.getElementById("record-button");
  if (recording) {
    endRecording();
  } else {
    navigator.mediaDevices
      .getDisplayMedia({ video: true, audio: true })
      .then((screenStream) => {
        screenStr = screenStream;
        const composedStream = new MediaStream();
        screenStream.getVideoTracks().forEach((videoTrack) => {
          composedStream.addTrack(videoTrack);
        });
        const context = new AudioContext();
        const audioDestination = context.createMediaStreamDestination();

        if (screenStream && screenStream.getAudioTracks().length > 0) {
          const systemSource = context.createMediaStreamSource(screenStream);
          const systemGain = context.createGain();
          systemGain.gain.value = 1.0;
          systemSource.connect(systemGain).connect(audioDestination);
        }

        const micSource = context.createMediaStreamSource(myStream);
        const micGain = context.createGain();
        micGain.gain.value = 1.0;
        micSource.connect(micGain).connect(audioDestination);

        audioDestination.stream.getAudioTracks().forEach((track) => {
          composedStream.addTrack(track);
        });

        composedStream.getVideoTracks()[0].addEventListener("ended", () => {
          endRecording();
        });

        recordingStream = composedStream;
        recording = true;
        const chunks = [];
        const recorder = new MediaRecorder(composedStream);
        recorder.ondataavailable = (e) => chunks.push(e.data);
        recorder.onstop = (e) => convertToMp4(chunks);
        recorder.start();
        record = recorder;
        recordButton.classList.remove("bg-gray-700");
        recordButton.classList.add("bg-red-500");
      });
  }
};

const recordButton = document.getElementById("record-button");
if (recordButton) recordButton.onclick = toggleRecording;
