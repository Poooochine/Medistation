const accountContainer = document.getElementById("accountContainer");

const accountType = document.getElementById("accountType");

const filterForm = document.getElementById("filter");
const staff = document.getElementById("staff");

const params = new URLSearchParams(window.location.search);
const selected = params.get("staff");

staff.value = selected;

if (!selected) {
  staff.value = "Physician";
  filterForm.submit();
}

function filterStaff() {
  filterForm.submit();
}

staff.onchange = filterStaff;

const phyDiv = document.createElement("div");
const phyLabel = document.createElement("label");
const phyInputDiv = document.createElement("div");
const phySpan = document.createElement("span");
const phyInput = document.createElement("input");

phyDiv.className = "flex flex-col justify-center";
phyLabel.for = "gender";
phyInputDiv.className = "flex bg-white px-2 py-1 shadow-lg rounded space-x-2";
phySpan.className = "material-icons text-gray-500";
phyInput.className = "outline-none grow";

const phyLabelText = document.createTextNode("Specialty");
phyLabel.appendChild(phyLabelText);

const phySpanText = document.createTextNode("people");
phySpan.appendChild(phySpanText);

phyDiv.appendChild(phyLabel);
phyInputDiv.appendChild(phySpan);
phyInputDiv.appendChild(phyInput);
phyDiv.appendChild(phyInputDiv);
phyInput.id = "specialty";
phyInput.name = "specialty";
phyInput.required = true;

accountType.onchange = (event) => {
  console.log(event.target.value);
  if (event.target.value === "Physician") {
    accountContainer.appendChild(phyDiv);
  } else {
    accountContainer.removeChild(phyDiv);
  }
};

var modalOpen = false;

function toggleModal() {
  const modal = document.getElementById("modal");
  if (modalOpen) {
    modal.classList.remove("flex");
    modal.classList.add("hidden");
    modalOpen = false;
  } else {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
    modalOpen = true;
  }
}

const cancelBtn = document.getElementById("cancel");
const openModal = document.getElementById("openModal");

cancelBtn.onclick = toggleModal;
openModal.onclick = toggleModal;
