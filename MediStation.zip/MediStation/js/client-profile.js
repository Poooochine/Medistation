const add = document.getElementById("add-img");
const image = document.getElementById("new-image");
const imageArea = document.getElementById("image-area");
const uploadButton = document.getElementById("upload-image");

uploadButton.disabled = true;

function addImage() {
  image.click();
}

add.onclick = addImage;

image.addEventListener("change", () => {
  if (image.files[0].type.includes("image")) {
    if (image.files[0].size > 5e6) {
      alert("Selected is greater than 5MB.");
      return;
    }
    uploadButton.disabled = false;
    var fr = new FileReader();
    fr.onload = function () {
      imageArea.src = fr.result;
    };
    fr.readAsDataURL(image.files[0]);
  } else {
    alert("Please select an image.");
  }
});
